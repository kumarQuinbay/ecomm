import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    cartItems: [],
    dd: 44
  },
  getters: {
    getCartItems (state) {
      return state.cartItems
    }
  },
  mutations: {
    setCartItems (state, item) {
      state.cartItems.push(item)
    },
    removeCartItem (state, item) {
      const index = state.cartItems.findIndex(obj => obj.productid === item.productid)
      state.cartItems.splice(index, 1)
    }
  },
  actions: {
  },
  modules: {
  }
})
