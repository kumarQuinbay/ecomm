<template>
  <main class="image">
    <navbar />
    <form>
      <h2>Sell Products</h2>
      <div id="container" style="margin: 20px auto 0; width: 500px">
        <br />
        <p>Category</p>
        <ejs-dropdownlist
          id="dropdownlist"
          popupHeight="200px"
          placeholder="Select a category"
          :fields="fields"
          :dataSource="dataSource"
        ></ejs-dropdownlist>
        <div>
          <br />
          <label>Product Name</label>
          <input
            class="e-input"
            type="text"
            placeholder="Enter Product Name"
          /><br /><br />
          <label>Product Description</label>
          <input
            class="e-input"
            type="text"
            placeholder="Enter Product Description"
          />
          <label>Product Image</label>
          <FormulateInput
            type="image"
            label=""
            validation="mime:image/jpeg,image/jpg,image/png"
            multiple
          />
          <br /><br />
          <label>Product Attribute</label>
          <form class="innerform"></form>
          <label>Product Version</label>
          <input
            class="e-input"
            type="text"
            placeholder="Enter Product Version"
          />

          <label>Quantity</label>
          <input
            class="e-input"
            type="text"
            placeholder="Enter Product Quantity"
          />

          <label>Price</label>
          <input
            class="e-input"
            type="text"
            placeholder="Enter Product Price"
          />

          <label>Location</label>
          <input class="e-input" type="text" placeholder="Enter Location" />

          <label>PinCode</label>
          <input class="e-input" type="text" placeholder="Enter PinCode" />
        </div>
      </div>
    </form>
  </main>
</template>

<script>
import Vue from 'vue'
import VueFormulate from '@braid/vue-formulate'
import navbar from '../components/navbar.vue'
import { DropDownListPlugin } from '@syncfusion/ej2-vue-dropdowns'
Vue.use(DropDownListPlugin)
Vue.use(VueFormulate)
export default {
  components: { navbar },
  data () {
    var Data = [
      { name: 'abc', Category: 'x', Id: 'item1' },
      { name: 'def', Category: 'x', Id: 'item2' },
      { name: 'ghi', Category: 'z', Id: 'item3' }
    ]
    return {
      dataSource: Data,
      fields: { groupBy: 'Category', text: 'name', value: 'Id' }
    }
  }
}
</script>

<style scoped>

.innerform {
  background-color: rgb(243, 245, 247);
  border: 1px solid grey;
  /* border-color: black; */
  text-align: left;
  height: auto;
  width: auto;
  margin: 1%;
  color: black;
}
form {
  background-color: rgb(243, 245, 247);
  border: 15px solid black;
  border-color: black;
  text-align: center;
  height: auto;
  width: 50%;
  margin: 82px 0px 50px 310px;
  padding: 2%;
  color: black;
}
.image {
    padding-top: 66px;
  background-image: url(https://previews.123rf.com/images/rrraven/rrraven1110/rrraven111000003/10755544-sport-background.jpg);
  height: 1000px;
}

@import "../../node_modules/@syncfusion/ej2-base/styles/material.css";
@import "../../node_modules/@syncfusion/ej2-inputs/styles/material.css";
@import "../../node_modules/@syncfusion/ej2-vue-dropdowns/styles/material.css";
</style>
