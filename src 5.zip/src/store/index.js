import Vue from 'vue'
import Vuex from 'vuex'
import axios from 'axios'

Vue.use(Vuex)
const server = 'http://10.177.68.2:8070'
const addId = server + '/user/register'

export default new Vuex.Store({
  state: {
    cartItems: [],
    dd: 44
  },
  getters: {
    getCartItems (state) {
      return state.cartItems
    }
  },
  mutations: {
    setCartItems (state, item) {
      state.cartItems.push(item)
    },
    removeCartItem (state, item) {
      const index = state.cartItems.findIndex(obj => obj.productid === item.productid)
      state.cartItems.splice(index, 1)
    }
  },
  actions: {
    postData ({ commit }, { data, success }) {
      debugger
      const detailsId = {
        firstName: data.firstName,
        lastName: data.lastName,
        mobileNumber: data.mobileNumber,
        email: data.email,
        password: data.password
      }
      axios.post(addId, detailsId)
        .then(res => {
          console.log(res)
          success()
        })
    }
  },
  modules: {
  }
})
