<template>
<main>
    <navbar/>
    <div class="main">
    <div class="topnav">
                <a  href="#Cricket" class="categories">Cricket</a>
                <a href="#Badminton" class="categories">Badminton</a>
                <a href="#Tennis" class="categories">Tennis</a>
                <a href="#Football" class="categories">Football</a>
                <a href="#Skating" class="categories">Skating</a>
        </div>
        <div class='fixy'>
                 <h2> shop by categories</h2>
        </div>
        <div class="container">
                <div class="row">
                  <div class="column">
                    <a href = '_'><img class='imgs' src='https://media.istockphoto.com/photos/closeup-of-red-cricket-ball-and-bat-sitting-on-grass-picture-id177427917?k=20&m=177427917&s=612x612&w=0&h=kr-FOxME8KOnnhYsuR6WFAfB-Hv_ch20Fz5xnzeSU10=' width='102%' height='200'></a>
                  </div>
                  <div class="column">
                    <a href=" "><img class="imgs" src='https://w0.peakpx.com/wallpaper/587/891/HD-wallpaper-badminton-racket-sports-equipment-closeup.jpg' width='120%' height="200"></a>
                </div>
                </div>
                <div class="row">
                   <div class="column">
                    <a href=" "><img class="imgs" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRhPunT_GTdH_jyx2yloVHlV2JFrv8YKRpI_g&usqp=CAU" width="102%" height="200"></a>
                   </div>
                   <div class="column">
                    <a href=" "><img class="imgs" src="file:///Users/gadiyaramsaidurgaharshitha/Desktop/football.jpeg " width="110%" height="200"></a>
                   </div>
                </div>
                <div class="row">
                  <div class="column">
                    <a href=" "><img class="imgs" src="file:///Users/gadiyaramsaidurgaharshitha/Desktop/shuttle.jpeg " width="102%" height="200"></a>
                  </div>
                </div>

        </div>
    </div>
</main>
</template>

<script>
import navbar from '../components/navbar.vue'
export default {
  components: {
    navbar
  }
}
</script>

<style scoped>
.main{
  padding-top: 90px;
}
body {
    padding: 0px;
    background-color: rgb(41, 51, 40);
    text-align: right;
}

    .header
    {
        overflow: hidden;
        background-color: rgb(91,112,82);
        padding: 25px;
        text-align: center;
        position:fixed;
        top:0;
        width: 100%;
    }
    .fixy
    {
        background-color: rgb(91,112,82);
        padding: 5px;
        text-align: center;
        width:100%;
    }
    input[type=text]
    {
        width: 40%;
        padding: 10px;
        text-align: center;
    }
    .topnav
    {
        background-color: rgb(56, 67, 50);
        text-align: center;
        width: 100%;
    }
    .categories:link, a:visited {
       background-color: rgb(56, 67, 50);
       color: white;
       padding: 16px ;
       text-align: center;
       text-decoration: none;
       display: inline-block;
    }

.categories:hover, a:active {
  background-color: black;
}
.column {
  float: left;
  width: 45%;
  padding: 5px;
}
.row:after {
  content: "";
  display: table;
  clear: both;
}

</style>
