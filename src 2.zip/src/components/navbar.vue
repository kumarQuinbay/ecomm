<template>
  <main class='container'>
    <section class='logo'><div id="circle"></div>
        <h1 style="font-size: 2px">ghkas</h1></section>
    <div class='header'>
             <input type ="text" placeholder="search" name="search">
         </div>
  </main>
</template>

<script>
export default {

}
</script>

<style scoped>
.header
    {
        overflow: hidden;
        background-color: rgb(91,112,82);
        padding: 25px;
        text-align: center;
        position:fixed;
        top:0;
        width: 100%;
    }
.container{
  display: flex;
}
</style>
