<template>
  <hello-world />
</template>

<script>
// import navbar from '../components/navbar.vue'

export default {
  name: 'Home',

  components: {
  }
}
</script>
