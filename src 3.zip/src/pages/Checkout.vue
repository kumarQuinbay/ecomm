<template>
<divclass="payment">
<img :src="image" />
<h1><b>Thankyou for Shopping!!</b></h1>
</div>


</template>

<script>
export default {

}
</script>

<style>

</style>